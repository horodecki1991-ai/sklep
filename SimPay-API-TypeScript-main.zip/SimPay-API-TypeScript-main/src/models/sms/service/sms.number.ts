export interface SmsNumber {
    number: number;

    value: number;
    value_gross: number;

    adult: boolean;
}
