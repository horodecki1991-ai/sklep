export enum SmsServiceType {
    ONE_TIME_CODE = 'ONE_TIME_CODE',
    CODE_PACK = 'CODE_PACK',
    API_URL = 'API_URL',
}
