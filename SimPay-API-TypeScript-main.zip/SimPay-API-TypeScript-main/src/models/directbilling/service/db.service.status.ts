export enum DBServiceStatus {
    SERVICE_NEW = 'service_db_new',
    SERVICE_ACTIVE = 'service_db_active',
    SERVICE_REJECTED = 'service_db_rejected',
    SERVICE_ONGOING_REGISTRATION = 'service_db_ongoing_registration',
}
