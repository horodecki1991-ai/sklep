export enum AmountType {
    REQUIRED = 'required',
    NET = 'net',
    GROSS = 'gross',
}
